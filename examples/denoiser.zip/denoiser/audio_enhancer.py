"""Source: https://github.com/facebookresearch/denoiser"""
import os
import json
import torch
import argparse 
import torchaudio
import torchaudio.functional as F
from rich.console import Console
from denoiser.demucs import Demucs

CONSOLE = Console(width=120)


def print_config(config: dict) -> None:
    """Writes configuration file to stdout

    Args:
        config (dict): JSON dictionary with training parameters of Demucs architecture
    """
    CONSOLE.log("Model config:")
    max_key_len = max([len(key) for key in config.keys()])
    for key, value in config.items():
        key_str = key + " " * (max_key_len - len(key))
        CONSOLE.log(f"{key_str} = {value}")
    print()


def load_audio(filepath: str, sample_rate: int) -> torch.Tensor:
    """Loads audio from file and optionally resamples it to 16kHz mono (as expected by model).

    Args:
        filepath (str):    Path to audio file.
        sample_rate (int): Expected sampling rate (16kHz).

    Returns:
        torch.Tensor: Audio waveform, optionally resampled to 16kHz mono.
    """
    audio, sr = torchaudio.load(filepath)

    # Stereo to mono
    if audio.shape[0] > 1:
        audio = torch.mean(audio, dim=0, keepdim=True)

    # Conversion to expected sampling rate of 16kHz (if not already 16kHz)
    if sr != sample_rate:
        audio = F.resample(audio, orig_freq=sr, new_freq=sample_rate)

    return audio


def write_audio(orig_filepath: str, sample_rate: int, format: str = "wav", postfix: str = "") -> str:
    """Exports enhanced audio waveform to file.

    Args:
        orig_filepath (str):     Path to original audio file 
        sample_rate (int):       Sampling rate of the enhanced waveform
        format (str):            Extension of output file (defaults to "wav")
        postfix (str, optional): Postfix to append to orig_filepath to create output filepath 
    """
    outfile = os.path.splitext(orig_filepath)[0] + f"{postfix}.{format}"
    torchaudio.save(outfile, src=output, sample_rate=sample_rate)
    return outfile


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="A simple speech enhancement and separation program built on 'denoiser' by Facebook Research. For details, visit 'https://github.com/facebookresearch/denoiser'.")
    parser.add_argument("-fp", "--filepath", type=str, required=True, help="Audio file to which to apply speech enhancement")
    parser.add_argument("-mp", "--model_path", type=str, default="models/master64", help="Path to pretrained audio enhancement and separation model.")
    parser.add_argument("-f", "--format", type=str, default="wav", choices=["wav", "ogg", "flac"], help="Output format of enhanced audio file.")
    parser.add_argument("-p", "--postfix", type=str, default="_enhanced", help="Postfix to append to output filename")
    parser.add_argument("-v", "--verbose", type=bool, default=False, help="Whether to print logs to stdout")
    args = parser.parse_args()

    # Load config file
    path_to_config = os.path.join(args.model_path, "config.json")
    with open(path_to_config, 'r', encoding='utf-8') as file:
        config = json.load(file)

        if args.verbose:
            print_config(config)

    # Load model from file
    path_to_ckpt = os.path.join(args.model_path, "checkpoint.th")
    enhancer = Demucs(**config)
    enhancer.load_state_dict(state_dict=torch.load(path_to_ckpt))

    # Push model to CUDA GPU if available
    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    enhancer.to(device)

    if args.verbose:
        CONSOLE.log(f"Running '{args.model_path}' enhancer on {device.upper()}")

    # Load audio waveform from file
    audio = load_audio(filepath=args.filepath, sample_rate=enhancer.sample_rate)
    if args.verbose:
        CONSOLE.log(f"Enhancing '{args.filepath}'")

    # Run Demucs enhancer
    output = enhancer(audio).squeeze(0).detach() # Remove channel

    # Save enhanced audio
    outfile = write_audio(
        orig_filepath=args.filepath, 
        sample_rate=enhancer.sample_rate, 
        postfix=args.postfix, 
        format=args.format
        )
    
    if args.verbose:
        CONSOLE.log(f"Saved to '{outfile}'!")